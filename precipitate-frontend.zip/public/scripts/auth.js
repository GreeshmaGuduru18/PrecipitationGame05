const email = localStorage.getItem('email');
if(!email){
    window.location.href="index.html"
}