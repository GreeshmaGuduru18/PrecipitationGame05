function logout(){
    localStorage.clear()
    window.location.reload(true);
}